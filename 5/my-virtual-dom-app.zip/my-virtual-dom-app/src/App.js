import React, { useState } from "react";
function App() {
 const [count, setCount] = useState(0); // Step 1: State for count
 return (
 <div style={{ textAlign: "center", marginTop: "50px" }}>
 <h1>Virtual DOM Example</h1>
 <h2>Count: {count}</h2> {/* Step 2: Shows current count */}
 <button onClick={() => setCount(count + 1)}>Increase</button> {/* Step 3:
Button to increase */}
 </div>
 );
}
export default App;